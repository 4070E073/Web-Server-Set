<table border="1" width="500">
<tr>
<td>1.CPU</td>
<td>選項<form>
<select name="YourLocation">
　<option value="AMD">AMD Ryzen TR 3960X</option>
　<option value="Intel">Intel i9 9900K</option>
　
　...
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
<tr>
<td>2.主機板</td>
<td>選項<form>
<select name="YourLocation">
　<option value="66">華碩 TUF H310M-PLUSGAMING</option>
　
　...
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
<tr>
<td>3.記憶體</td>
<td>選項<form>
<select name="YourLocation">
　<option value="DDR4">金士頓 16GB DDR4-3200</option>
　
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
<tr>
<td>4.傳統硬碟</td>
<td>選項<form>
<select name="YourLocation">
　<option value="傳統硬碟">Seagate 8TB 冷儲存碟</option>
　
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
<tr>
<td>5.固態硬碟</td>
<td>選項<form>
<select name="YourLocation">
　<option value="固態硬碟">技嘉 AORUS 2TB</option>
　
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
<tr>
<td>6.散熱器</td>
<td>選項<form>
<select name="YourLocation">
　<option value="散熱器">水冷</option>
　
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
<tr>
<td>7.顯示卡</td>
<td>選項<form>
<select name="YourLocation">
　<option value="顯示卡">NVDIA RTX2080</option>
　
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
<tr>
<td>8.機殼</td>
<td>選項<form>
<select name="YourLocation">
　<option value="機殼">Scythe Kaze Flex 120</option>
　
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
<tr>
<td>9.電源供應器</td>
<td>選項<form>
<select name="YourLocation">
　<option value="電源供應器">華碩 ROG THOR 1200P</option>
　
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
<tr>
<td>10.作業系統</td>
<td>選項<form>
<select name="YourLocation">
　<option value="作業系統">Win 10 專業版</option>
　
</select>
</form></td>
<td>價格<form>
<select name="YourLocation">
　
</select>
</form></td>
</tr>
</table>